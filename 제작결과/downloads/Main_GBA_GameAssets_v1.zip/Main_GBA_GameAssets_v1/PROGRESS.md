# 주요 캐릭터 GBA풍 동작 초안 진행 기록

현재 나루토·사스케의 작은 전투 유닛 그림체를 참고합니다. 원본 복장과 무기는 각 캐릭터의 실제 GitHub 이미지에서 확인합니다.

| 캐릭터 | 저장 동작 | 프레임 |
|---|---|---:|
| 하루노 사쿠라 | idle, move, attack, hit, down, cast | 18 |
| 하타케 카카시 | idle, move, attack, hit, down, cast | 18 |
| 록 리 | idle, move, attack, hit, down, cast | 18 |
| 휴우가 네지 | idle, move, attack, hit, down, cast | 18 |
| 휴우가 히나타 | idle, move, attack, hit, down, cast | 18 |
| 나라 시카마루 | idle, move, attack, hit, down, cast | 18 |
| 가아라 | idle, move, attack, hit, down, cast | 18 |
| 테마리 | idle, move, attack, hit, down, cast | 18 |
| 텐텐 | idle, move, attack, hit, down, cast | 18 |
| 야마나카 이노 | idle, move, attack, hit, down, cast | 18 |
| 아키미치 쵸지 | idle, move, attack, hit, down, cast | 18 |
| 아부라메 시노 | idle, move, attack, hit, down, cast | 18 |
| 이누즈카 키바 | idle, move, attack, hit, down, cast | 18 |
| 마이트 가이 | idle, move, attack, hit, down, cast | 18 |
| 지라이야 | idle, move, attack, hit, down, cast | 18 |
| 츠나데 | idle, move, attack, hit, down, cast | 18 |
| 사루토비 히루젠 | idle, move, attack, hit, down, cast | 18 |
| 우치하 이타치 | idle, move, attack, hit, down, cast | 18 |
| 호시가키 키사메 | idle, move, attack, hit, down, cast | 18 |
| 오로치마루 | idle, move, attack, hit, down, cast | 18 |
| 야쿠시 카부토 | idle, move, attack, hit, down, cast | 18 |
| 칸쿠로 | idle, move, attack, hit, down, cast | 18 |
| 사콘 | idle, move, attack, hit, down, cast | 18 |
| 지로보 | idle, move, attack, hit, down, cast | 18 |
| 키도마루 | idle, move, attack, hit, down, cast | 18 |
| 키미마로 | idle, move, attack, hit, down, cast | 18 |
| 타유야 | idle, move, attack, hit, down, cast | 18 |
| 사루토비 아스마 | idle, move, attack, hit, down, cast | 18 |
| 유우히 쿠레나이 | idle, move, attack, hit, down, cast | 18 |
| 카미즈키 이즈모 | idle, move, attack, hit, down, cast | 18 |
| 하가네 코테츠 | idle, move, attack, hit, down, cast | 18 |
| 데이다라 | idle, move, attack, hit, down, cast | 18 |
| 코난 | idle, move, attack, hit, down, cast | 18 |
| 페인 | idle, move, attack, hit, down, cast | 18 |
| 사소리 | idle, move, attack, hit, down, cast | 18 |
| 사소리 히루코 | idle, move, attack, hit, down, cast | 18 |
| 3대 카제카게 꼭두각시 | idle, move, attack, hit, down, cast | 18 |
| 킨 츠치 | idle, move, attack, hit, down, cast | 18 |
| 도스 키누타 | idle, move, attack, hit, down, cast | 18 |
| 자쿠 아부미 | idle, move, attack, hit, down, cast | 18 |
| 우즈마키 나루토(구미화) | idle, move, attack, hit, down, cast | 18 |
| 우치하 사스케(주인술) | idle, move, attack, hit, down, cast | 18 |
| 사콘(주인술) | idle, move, attack, hit, down, cast | 18 |
| 지로보(주인술) | idle, move, attack, hit, down, cast | 18 |
| 키도마루(주인술) | idle, move, attack, hit, down, cast | 18 |
| 키미마로(주인술) | idle, move, attack, hit, down, cast | 18 |
| 타유야(주인술) | idle, move, attack, hit, down, cast | 18 |
| 사소리(꼭두각시 몸체) | idle, move, attack, hit, down, cast | 18 |
| 센쥬 하시라마(예토전생) | idle, move, attack, hit, down, cast | 18 |
| 센쥬 토비라마(예토전생) | idle, move, attack, hit, down, cast | 18 |
| 우미노 이루카 | idle, move, attack, hit, down, cast | 18 |
| 사루토비 코노하마루 | idle, move, attack, hit, down, cast | 18 |
| 시즈네 | idle, move, attack, hit, down, cast | 18 |
| 미타라시 앙코 | idle, move, attack, hit, down, cast | 18 |
| 유우히 쿠레나이(붕대형 복장) | idle, move, attack, hit, down, cast | 18 |
| NPC 07(검은 모자·청색 복장) | idle, move, attack, hit, down, cast | 18 |
| NPC 08(모자·조끼) | idle, move, attack, hit, down, cast | 18 |

기본6동작 세트가 있는 캐릭터: 57명. 저장한 프레임: 1026개.

대기1·이동4·공격4·피격2·쓰러짐3·시전4를 기본으로 합니다. 무기/장비 보유자는 자기 장비에 맞춘 동작을 사용합니다. 시전 자세만으로 모든 인술을 사용할 수 있다는 의미는 아닙니다.
각 캐릭터 폴더에 frames(투명 PNG), sheets(동작 시트), previews(확대 비교/GIF), prompts(정확한 생성 지시), sources(생성 원본), metadata(시간/기준점)를 저장합니다.
몸의 크기는 약33px이며, 가아라의 호리병과 테마리의 부채처럼 장비가 붙으면 전체 높이가 다릅니다. 캔버스는 기본96×64, 히루코·키미마로 주인술은128×64이며 공통 기준점은(48,56)입니다. 색 수는 캐릭터별12색 이하 공통 팔레트입니다.
이미지 생성 도구로 만든 동작 초안이며 수동 도트 마감·게임 엔진 검증은 진행하지 않았습니다. 발사체·인술·상대 타격 효과는 별도입니다.
기존 나루토·사스케·범용 캐릭터 제작본은 별도 폴더에 보존되어 있습니다.
